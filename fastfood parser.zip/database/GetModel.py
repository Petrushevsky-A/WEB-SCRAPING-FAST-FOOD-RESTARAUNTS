
from .model import hotukdeals
from .model import dominos

TABLE = {
    'STG_HOTUKDEALS_BURGERKING_DEALS_CARDS': hotukdeals.MODELTABLE,
    'STG_DOMINOS_PRICE': dominos.MODELTABLE,

}